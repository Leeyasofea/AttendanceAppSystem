buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies { classpath'com.android.tools.build:gradle:8.1.0' }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
